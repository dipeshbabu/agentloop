# Ablation: Declared read-only SQL scheduling

Descriptive host observations, not causal identification. Intervals give equal weight to observed task means within each split/cache stratum; repetitions are not independent tasks. Missingness, selection, small task counts, order/carryover effects and scorer errors remain limitations. A frozen hash is not proof of preregistration or environment reset. Policy evaluation time is not end-to-end overhead. Synthetic fixtures are not empirical benefits.

Evidence: host-supplied study; permissions and execution require external verification.

Planned observations: 96; observed: 96; unplanned: 0.

Execution statuses: `{"completed": 96}`

Token completeness: `{"empty": 96}`

Cost completeness / basis: `[{"unknown": 96}, {"unknown": 96}]`

Stop reasons: `{}`

Deltas are candidate minus baseline. Negative latency/cost deltas are reductions, not evidence of task success.

| Comparison | Split / cache | Planned | Quality accepted | Rejected | Indeterminate | Unmatched |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| off -&gt; trace (trace_overhead) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| off -&gt; trace (trace_overhead) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| shadow_budget -&gt; enforce_budget (enforcement_effect) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| shadow_budget -&gt; enforce_budget (enforcement_effect) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| trace -&gt; enforce_budget (total_policy_effect) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; enforce_budget (total_policy_effect) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| shadow_combined -&gt; enforce_combined (enforcement_effect) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| shadow_combined -&gt; enforce_combined (enforcement_effect) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| trace -&gt; enforce_combined (total_policy_effect) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; enforce_combined (total_policy_effect) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| shadow_schedule -&gt; enforce_schedule (enforcement_effect) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| shadow_schedule -&gt; enforce_schedule (enforcement_effect) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| trace -&gt; enforce_schedule (total_policy_effect) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; enforce_schedule (total_policy_effect) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| trace -&gt; shadow_budget (policy_shadow_overhead) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; shadow_budget (policy_shadow_overhead) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| trace -&gt; shadow_combined (policy_shadow_overhead) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; shadow_combined (policy_shadow_overhead) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |
| trace -&gt; shadow_schedule (policy_shadow_overhead) | held_out / warm_os_cache | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; shadow_schedule (policy_shadow_overhead) | pilot / warm_os_cache | 4 | 4 | 0 | 0 | 0 |

## off -> trace: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.07677499979763525 | 0.07677499979763525 | &#91;-0.378587, 0.5147&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |

## off -> trace: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | -0.15809999968041666 | -0.15809999968041666 | &#91;-0.75585, 0.43965&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |

## shadow_budget -> enforce_budget: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -0.035387498428463005 | -0.035387498428463005 | &#91;-0.216025, 0.246587&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | -0.10855000000000001 | -0.10855000000000001 | &#91;-0.178775, -0.038325&#93; |

## shadow_budget -> enforce_budget: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | -0.1410249951732112 | -0.1410249951732112 | &#91;-0.4885, 0.20645&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | -0.13272499999999987 | -0.13272499999999987 | &#91;-0.1578, -0.10765&#93; |

## trace -> enforce_budget: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 5.409525001596194 | 5.409525001596194 | &#91;5.03218, 5.78688&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.770675 | 1.770675 | &#91;1.72523, 1.81612&#93; |

## trace -> enforce_budget: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | 5.953800004135701 | 5.953800004135701 | &#91;4.8862, 7.0214&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 1.9335499999999999 | 1.9335499999999999 | &#91;1.7867, 2.0804&#93; |

## shadow_combined -> enforce_combined: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -2.2930249997443752 | -2.2930249997443752 | &#91;-2.81105, -1.74752&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.01748749999999996 | 0.01748749999999996 | &#91;-0.0921, 0.127075&#93; |

## shadow_combined -> enforce_combined: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | -4.502525000134483 | -4.502525000134483 | &#91;-4.9671, -4.03795&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | -0.06849999999999995 | -0.06849999999999995 | &#91;-0.1019, -0.0351&#93; |

## trace -> enforce_combined: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 4.532637499323755 | 4.532637499323755 | &#91;3.89555, 5.33161&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.9565625 | 1.9565625 | &#91;1.84932, 2.0638&#93; |

## trace -> enforce_combined: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | 2.9507999988709344 | 2.9507999988709344 | &#91;2.87295, 3.02865&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 1.9141249999999999 | 1.9141249999999999 | &#91;1.8787, 1.94955&#93; |

## shadow_schedule -> enforce_schedule: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -3.22889999824838 | -3.22889999824838 | &#91;-3.68497, -2.45951&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.020175000000000002 | 0.020175000000000002 | &#91;0.0165875, 0.0222878&#93; |

## shadow_schedule -> enforce_schedule: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | -3.8315999972837744 | -3.8315999972837744 | &#91;-4.3951, -3.2681&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 0.025775000000000003 | 0.025775000000000003 | &#91;0.02475, 0.0268&#93; |

## trace -> enforce_schedule: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.8787625019976986 | 0.8787625019976986 | &#91;0.1606, 1.59693&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.071775 | 0.071775 | &#91;0.070375, 0.073075&#93; |

## trace -> enforce_schedule: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | -0.1680249988567084 | -0.1680249988567084 | &#91;-0.81535, 0.4793&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 0.077675 | 0.077675 | &#91;0.0703, 0.08505&#93; |

## trace -> shadow_budget: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 5.444912500024657 | 5.444912500024657 | &#91;5.2482, 5.64163&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.879225 | 1.879225 | &#91;1.85445, 1.90602&#93; |

## trace -> shadow_budget: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | 6.094824999308912 | 6.094824999308912 | &#91;5.3747, 6.81495&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 2.0662749999999996 | 2.0662749999999996 | &#91;1.9445, 2.18805&#93; |

## trace -> shadow_combined: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 6.82566249906813 | 6.82566249906813 | &#91;6.5505, 7.10359&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.939075 | 1.939075 | &#91;1.92931, 1.94921&#93; |

## trace -> shadow_combined: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | 7.453324999005417 | 7.453324999005417 | &#91;7.0666, 7.84005&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 1.982625 | 1.982625 | &#91;1.9806, 1.98465&#93; |

## trace -> shadow_schedule: held_out / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 4.107662500246079 | 4.107662500246079 | &#91;3.55377, 5.0253&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.0516 | 0.0516 | &#91;0.0486375, 0.0561375&#93; |

## trace -> shadow_schedule: pilot / warm_os_cache

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 4 | 0 / 0 / 2 | unavailable | unavailable | insufficient tasks |
| latency_ms | 4 / 4 / 4 | 2 / 2 / 2 | 3.663574998427066 | 3.663574998427066 | &#91;2.45275, 4.8744&#93; |
| tokens | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 4 / 4 / 4 | 2 / 2 / 2 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 4 / 4 / 4 | 2 / 2 / 2 | 0.0519 | 0.0519 | &#91;0.04555, 0.05825&#93; |

Full JSON retains every observation, protocol deviation, stop reason, duplicate/missing pair, metric denominator and task-level interval.
