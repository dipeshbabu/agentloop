# Attribution

Wine Quality: Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009). Wine Quality [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56S3T . CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . Original red/white CSV bytes are retained. The derived SQLite database normalizes column names, stores numeric values and adds a color field; its dataset rights remain CC BY 4.0. Study queries and scheduling code are original Apache-2.0 code. See LICENSE. No model or inference runtime is distributed.
