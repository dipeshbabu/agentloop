# Reproduce declared read-only scheduling

All96 observations and384 queries are retained. All ordered outputs match independent frozen reference rows. Four held-out batches repeated twice across8conditions remain8pairs per comparison, not8independent tasks. Enforced scheduling reaches4running callbacks, beats the corresponding shadow scheduler, but is slower than tracing alone on these small operations. Costs are unknown whole-workload costs; model-call costs/tokens are empty because no model was invoked. Paid-provider spend0.

Use a complete AgentLoop checkout at33646da91515bbf0add2f060ee5dbecebc8d75f4 plus all included source/ files, preserving bytes. These snapshots are an overlay, not an installable distribution. Native ablation/study schemas are reused; no estimator attribution is invented for the explicit resource/dependency plan.

Recompute without callbacks:

    python -m examples.scheduling_study.export --plan PATH_TO_UNPACKED/study/plan.json --out NEW_REPORT_DIRECTORY

For a new experiment, prepare a fresh root using examples.scheduling_study.protocol --out NEW_ROOT --sources study/sources, then explicitly run examples.scheduling_study.runner --plan NEW_ROOT/plan.json --execute. No model download or network service is needed. Each callback opens/closes its own mode=ro SQLite connection with query_only and a restrictive authorizer. The source CSV and resulting database hashes are checked. All inputs, labels, policies and implementation hashes are frozen before execution.

The time includes tool/scheduler/harness and thread-pool setup, SQL connections, queries, result collection, cleanup and enabled tracing. Database creation, independent scoring and export are excluded. OS caches remain warm and the host is shared. No artificial sleep simulates tool latency. Held-out condition order is balanced; pilot order has only four cyclic positions. Statistical intervals resample task means.

Original receipts, schedules, native policy evidence, raw traces, public data, source and reports are retained without redaction. Server/model artifacts are absent because there is no inference. This experiment validates declared read-only orchestration; it does not establish safety for undeclared side effects, hard thread termination or automatic replay of mutations.
