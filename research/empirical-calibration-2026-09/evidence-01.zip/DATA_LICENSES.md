# Attribution and scope

GSM8K: copyright (c) 2021 OpenAI, MIT. The full license is study/gsm8k-LICENSE.txt. Original source revision 3101c7d5072418e28b9008a6636bde82a006892c and SHA-256 are in the frozen protocol. New selected question text and numeric references are retained there; no model outcomes were used to choose them.

Earlier routing traces include UCI Wine Quality data-derived results: Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009), Wine Quality [Dataset], UCI Machine Learning Repository, https://doi.org/10.24432/C56S3T , CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . Full original datasets and licenses are also available in the #181 real-agent bundle. AgentLoop source and study code are Apache-2.0; dataset rights remain separate.

No model weights, inference runtime binaries or third-party dependency code are redistributed. Original traces, predictions and ledger records are unchanged. The retired onboarding cohort and count-cap safety-policy study are documented exclusions, not fabricated estimator measurements.
