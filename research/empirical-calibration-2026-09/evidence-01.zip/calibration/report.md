# Calibration: Real local-model historical calibration: attribution retained

Historical descriptive calibration, not a causal or universal-confidence claim. Savings are baseline minus candidate; signed error is prediction minus realized savings (positive means overprediction). Synthetic, ambiguous and unverifiable cases are excluded from empirical aggregates but retained. All measurable outcomes, including failures and unknown quality, enter raw error summaries and any requested scale fit. Quality-preserving subsets are conditional and retain denominators. Scale fitting targets raw resource savings, never task utility; fitting-task error is in-sample and held-out error is separate. Task means, not seeds, are the bootstrap units. Selection, missingness, small-task uncertainty, multiplicity, scorer validity and workload drift remain limitations. No estimator or runtime policy is modified.

Registrations: 184; synthetic excluded: 0.

Selection inventory declared complete: True. This is a host declaration, not proof of unbiased selection.

Freshness at 2026-09-24T01:34:40.318364+00:00: within declared validity window; valid until 2026-10-01T01:34:40.318364+00:00.

## cal_14fc0ee17c8d0f4e283eb8ea54c9506ed1ec5f630b6728c9500cbdb3d1e460a3

Workload: agent-tool-loop:math:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"cache_context","estimator_version":"1.0","formula":"current_cost_usd * min(max_cost_fraction, repeated_context_ratio)","method":"heuristic","parameters":{"max_cost_fraction":0.5}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"outside_selected_routing_scope":14}`

Excluded/unverifiable evidence: `{"not_selected":14,"outcome_not_recorded":14}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_45ca1d98726fdc577e3b05e98b019aa5351e2f198afdc43923058d865434faa7

Workload: agent-tool-loop:repository:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"batch_model_calls","estimator_version":"1.0","formula":"sum_duration_ms * latency_fraction","method":"heuristic","parameters":{"latency_fraction":0.35}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"outside_selected_routing_scope":14}`

Excluded/unverifiable evidence: `{"not_selected":14,"outcome_not_recorded":14}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_65c95209533d75ddc4389f18a77cbbbd8a4c84e586aca6716f3c6a61892a2434

Workload: agent-tool-loop:sql:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"route_to_smaller_model","estimator_version":"1.0","formula":"sum_duration_ms * latency_fraction","method":"heuristic","parameters":{"latency_fraction":0.25}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"preregistered_routing":28}`

Excluded/unverifiable evidence: `{"combined_intervention_unattributed":28,"duplicate_outcome":28}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 4 | 4 | 0 / 0 / 4 | 0/4; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 24 | 24 | 0 / 0 / 24 | 0/24; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 4 | 4 | 0 / 0 / 4 | 0/4; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 24 | 24 | 0 / 0 / 24 | 0/24; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_7547dc325bc3825fc02f68944b06ea89f21fda404169d18ca3e1eec96f2ab715

Workload: agent-tool-loop:sql:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"cache_context","estimator_version":"1.0","formula":"current_cost_usd * min(max_cost_fraction, repeated_context_ratio)","method":"heuristic","parameters":{"max_cost_fraction":0.5}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"outside_selected_routing_scope":14}`

Excluded/unverifiable evidence: `{"not_selected":14,"outcome_not_recorded":14}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_786f9709a3ad63a2e141533c02e064829bcd3b97bb2ba88b0724610e532440f5

Workload: agent-tool-loop:repository:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"parallelize_tools","estimator_version":"1.0","formula":"sum_duration_ms - max_duration_ms","method":"heuristic","parameters":{}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"outside_selected_routing_scope":14}`

Excluded/unverifiable evidence: `{"not_selected":14,"outcome_not_recorded":14}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_a340e20208e50b53c4ab5019146f43768a26b6030d9e4c8d6eadc0414038a8bf

Workload: agent-tool-loop:repository:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"cache_context","estimator_version":"1.0","formula":"current_cost_usd * min(max_cost_fraction, repeated_context_ratio)","method":"heuristic","parameters":{"max_cost_fraction":0.5}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"outside_selected_routing_scope":14}`

Excluded/unverifiable evidence: `{"not_selected":14,"outcome_not_recorded":14}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 2 | 0 | 0 / 0 / 0 | 0/2; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 12 | 0 | 0 / 0 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: undefined (zero selected). Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_c0498b29543fcee9985876a038efd13283b187433f5dfd047e7ae2ce14840272

Workload: agent-tool-loop:math:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"route_to_smaller_model","estimator_version":"1.0","formula":"sum_duration_ms * latency_fraction","method":"heuristic","parameters":{"latency_fraction":0.25}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"preregistered_routing":28}`

Excluded/unverifiable evidence: `{"combined_intervention_unattributed":28,"duplicate_outcome":28}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 4 | 4 | 0 / 0 / 4 | 0/4; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 24 | 24 | 0 / 0 / 24 | 0/24; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 4 | 4 | 0 / 0 / 4 | 0/4; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 24 | 24 | 0 / 0 / 24 | 0/24; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_e1d3689ba36cd4f0f6870b5417ff9215e5a0477e28f74321d9c25d1aa57a9273

Workload: agent-tool-loop:repository:8ecc2029bc11232ed7ebbc9d283d7a647204e98508ae48f7be167054aa564f0a; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"route_to_smaller_model","estimator_version":"1.0","formula":"sum_duration_ms * latency_fraction","method":"heuristic","parameters":{"latency_fraction":0.25}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:efb7be52ce84787382dcca0f35f28c6c91dfe197c2e4750db786e65745a06dac","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"all model calls; original findings can cover a subset of those calls"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"real-agent-task-1.0:ca24fa5e10d83b3ae852b1671fd2bc67f0f758e936d8a6ba4c76d4c62c4fa040"}`

Selection reasons: `{"preregistered_routing":42}`

Excluded/unverifiable evidence: `{"combined_intervention_unattributed":42,"duplicate_outcome":42}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 6 | 6 | 0 / 0 / 6 | 0/6; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| latency / held_out | 36 | 36 | 0 / 0 / 36 | 0/36; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / fit | 6 | 6 | 0 / 0 / 6 | 0/6; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 36 | 36 | 0 / 0 / 36 | 0/36; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.


cost/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

## cal_f74cb3b91dd481b1a16840670f79678b2349f504326ec0c95dfa2f76558b1ed3

Workload: GSM8K direct-answer decision v1:024c94638b56caaeea29ccf25966bc754c45e221f5fd6f6f6efb92b54e5691b2; model/provider: sha256:9994b308390c48738bcfc60d2e26740708a36565be693fdb48663d5e2918b3ff / llama.cpp:b10964:b29c606e2:Vulkan; cost basis: unknown.

Estimator: `{"estimator_id":"route_to_smaller_model","estimator_version":"1.0","formula":"sum_duration_ms * latency_fraction","method":"heuristic","parameters":{"latency_fraction":0.25}}`

Environment/scorer/pricing/policy: `{"environment":"sha256:fdea5e910c75c2c4a2060018b5ac23f34c32e22d12b7a6529b07f2451eb3d62d","intervention":{"configuration":{"baseline":{"file":"Qwen3-4B-Instruct-2507-Q4_K_M.gguf","id":"Qwen3-4B-Instruct-2507-Q4_K_M","repository":"unsloth/Qwen3-4B-Instruct-2507-GGUF","revision":"a06e946bb6b655725eafa393f4a9745d460374c9","sha256":"3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597"},"candidate":{"file":"qwen2.5-1.5b-instruct-q4_k_m.gguf","id":"Qwen2.5-1.5B-Instruct-Q4_K_M","repository":"Qwen/Qwen2.5-1.5B-Instruct-GGUF","revision":"91cad51170dc346986eccefdc2dd33a9da36ead9","sha256":"6a1a2eb6d15622bf3c96857206351ba97e1af16c30d7a74ee38970e434e9407e"},"scope":"single answer model call"},"type":"model_routing"},"policy":null,"pricing":null,"quality_gate":{"max_regression":0,"min_score":1},"scorer":"bounded-numeric-answer-1.0:d0239f85d905231d32c4add7b068fa72c65f8655d16c5f5f48e06e6e68a6a49b"}`

Selection reasons: `{"frozen_single_decision_routing":16}`

Excluded/unverifiable evidence: `{}`

| Metric / split | Registered (non-synthetic) | Selected | Quality accepted / rejected / unknown | Evaluable / planned: observations; tasks | Mean original error | Mean scaled error | Mean realized savings | Original error interval |
| --- | ---: | ---: | --- | --- | ---: | ---: | ---: | --- |
| latency / fit | 4 | 4 | 0 / 4 / 0 | 4/4; 2/2 | -91.90700000000001 | -17.08967655404942 | 381.82675 | 95.0%: &#91;-258.144, 74.3295&#93; |
| latency / held_out | 12 | 12 | 0 / 12 / 0 | 12/12; 6/6 | 47.39833333333337 | 125.09597481932114 | 253.68274999999994 | 95.0%: &#91;-294.242, 414.101&#93; |
| cost / fit | 4 | 4 | 0 / 4 / 0 | 0/4; 0/2 | unavailable | unavailable | unavailable | insufficient tasks |
| cost / held_out | 12 | 12 | 0 / 12 / 0 | 0/12; 0/6 | unavailable | unavailable | unavailable | insufficient tasks |

latency/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


latency/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


latency diagnostic fit: fitted; factor: 1.2580621825382734; fitting tasks: 2. observed.


cost/fit quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/2.


cost/held_out quality acceptance among selected non-synthetic registrations: 0.0%. Conditional mean savings: None; eligible tasks: 0/6.


cost diagnostic fit: insufficient_tasks; factor: None; fitting tasks: 0. no_evaluable_held_out_outcomes.

Every registration, original snapshot, outcome status, exclusion reason, task/observation denominator and held-out scaled error remains in JSON. No runtime coefficients were changed.
