# Reproduce historical calibration

Use AgentLoop core source 0876e143010a753408c6dd032c8ca18e3380091a and the included study code. Run:

    agentloop study calibrate calibration/manifest.json --out NEW_REPORT.md --json-out NEW_REPORT.json

This reads the frozen manifest, original snapshots, source traces and ledgers. It makes no model calls, does not reprice old runs and changes no runtime coefficients. Relocating source paths changes path fields and the artifact hash; numerical cohort results remain identical. Do not regenerate an as_of date to make historical evidence appear fresh.

The manifest keeps 168 original revised-agent registrations (98 selected findings sharing 42 combined ledgers, 70 rejected findings) and 16 new single-decision pairs. Combined effects remain unattributed and are flagged as duplicate outcomes when referenced by multiple findings. None of those records has been split or rewritten. Old archive times came from the original execution directory's last-write metadata, verified before candidate starts and against already-published prediction hashes; those times are declared provenance, not independent preregistration proof. Extraction does not recover old file times. New single-decision journals explicitly timestamp predictions after archival and before candidates, then timestamp outcomes after ledger writes.

The new workload is direct numeric answer generation, not a new agent benchmark. It freezes two fitting and six held-out GSM8K tasks, two repetitions, a 32-token answer cap and independent bounded numeric scoring. All 32 attempts and 16 single-finding ledgers are retained. The candidate fails quality on every pair, including six malformed/truncated responses. Raw resource fitting includes those failures; no quality-preserving benefit or cost calibration is established.

New inference requires an explicitly prepared fresh protocol/root and --execute in examples/real_calibration_study.py. It verifies the loopback server's model file and SHA-256. Use the recorded baseline/candidate GGUF revisions and llama.cpp b10964 Vulkan configuration, run baseline before candidate in each repetition, and retain the readiness warmup separately. Model paths, hashes and bounds are in study/protocol.json. Do not overwrite original attempts or adjust held-out labels. A code/model/scorer/configuration change requires a new protocol and evaluation.

All operating costs remain unknown. Paid-provider spend was zero. The 1.258062 diagnostic latency scale from only two fitting tasks is not a production coefficient or quality model. Public benchmark contamination, fixed condition order, shared hardware, selection and small task counts limit conclusions.
