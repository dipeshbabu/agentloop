# Ablation: Local model: explicit optional-tool summary

Descriptive host observations, not causal identification. Intervals give equal weight to observed task means within each split/cache stratum; repetitions are not independent tasks. Missingness, selection, small task counts, order/carryover effects and scorer errors remain limitations. A frozen hash is not proof of preregistration or environment reset. Policy evaluation time is not end-to-end overhead. Synthetic fixtures are not empirical benefits.

Evidence: host-supplied study; permissions and execution require external verification.

Planned observations: 80; observed: 80; unplanned: 0.

Execution statuses: `{"completed": 80}`

Token completeness: `{"exact": 80}`

Cost completeness / basis: `[{"unknown": 80}, {"unknown": 80}]`

Stop reasons: `{}`

Deltas are candidate minus baseline. Negative latency/cost deltas are reductions, not evidence of task success.

| Comparison | Split / cache | Planned | Quality accepted | Rejected | Indeterminate | Unmatched |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| off -&gt; trace (trace_overhead) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| off -&gt; trace (trace_overhead) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| shadow_budget -&gt; enforce_budget (enforcement_effect) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| shadow_budget -&gt; enforce_budget (enforcement_effect) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| trace -&gt; enforce_budget (total_policy_effect) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; enforce_budget (total_policy_effect) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| shadow_combined -&gt; enforce_combined (enforcement_effect) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| shadow_combined -&gt; enforce_combined (enforcement_effect) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| trace -&gt; enforce_combined (total_policy_effect) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; enforce_combined (total_policy_effect) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| shadow_context -&gt; enforce_context (enforcement_effect) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| shadow_context -&gt; enforce_context (enforcement_effect) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| trace -&gt; enforce_context (total_policy_effect) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; enforce_context (total_policy_effect) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| trace -&gt; shadow_budget (policy_shadow_overhead) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; shadow_budget (policy_shadow_overhead) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| trace -&gt; shadow_combined (policy_shadow_overhead) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; shadow_combined (policy_shadow_overhead) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |
| trace -&gt; shadow_context (policy_shadow_overhead) | held_out / prompt_cache_disabled | 8 | 8 | 0 | 0 | 0 |
| trace -&gt; shadow_context (policy_shadow_overhead) | pilot / prompt_cache_disabled | 2 | 2 | 0 | 0 | 0 |

## off -> trace: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -42.0859375017244 | -42.0859375017244 | &#91;-83.1362, 29.341&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |

## off -> trace: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | -989.2006000045512 | -989.2006000045512 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |

## shadow_budget -> enforce_budget: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -78.57449999846722 | -78.57449999846722 | &#91;-109.586, -38.241&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | -0.34693749999999995 | -0.34693749999999995 | &#91;-1.29589, 0.41015&#93; |

## shadow_budget -> enforce_budget: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | -63.9211499983503 | -63.9211499983503 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | -0.8466 | -0.8466 | insufficient tasks |

## trace -> enforce_budget: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -9.79431250016205 | -9.79431250016205 | &#91;-65.4881, 34.1074&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.0412625 | 1.0412625 | &#91;0.834975, 1.32165&#93; |

## trace -> enforce_budget: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | -26.941700001771096 | -26.941700001771096 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 0.8080999999999999 | 0.8080999999999999 | insufficient tasks |

## shadow_combined -> enforce_combined: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 4619.958137501271 | 4619.958137501271 | &#91;4492.3, 4817.48&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 262.0 | 262.0 | &#91;262, 262&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 1.0 | 1.0 | &#91;1, 1&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.0597125 | 1.0597125 | &#91;0.612113, 1.29917&#93; |

## shadow_combined -> enforce_combined: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | 4828.923649998615 | 4828.923649998615 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 262.0 | 262.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 1.0 | 1.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 1.30335 | 1.30335 | insufficient tasks |

## trace -> enforce_combined: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 4629.6233124994615 | 4629.6233124994615 | &#91;4499.14, 4839.96&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 262.0 | 262.0 | &#91;262, 262&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 1.0 | 1.0 | &#91;1, 1&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 2.0999749999999997 | 2.0999749999999997 | &#91;1.74584, 2.41822&#93; |

## trace -> enforce_combined: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | 4802.4436499981675 | 4802.4436499981675 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 262.0 | 262.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 1.0 | 1.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 2.10685 | 2.10685 | insufficient tasks |

## shadow_context -> enforce_context: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 4485.800049998943 | 4485.800049998943 | &#91;4428.57, 4526.88&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 262.0 | 262.0 | &#91;262, 262&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 1.0 | 1.0 | &#91;1, 1&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.013099999999999999 | 0.013099999999999999 | &#91;0.0097125, 0.01635&#93; |

## shadow_context -> enforce_context: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | 4859.0408000018215 | 4859.0408000018215 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 262.0 | 262.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 1.0 | 1.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 0.00725 | 0.00725 | insufficient tasks |

## trace -> enforce_context: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 4467.72533749845 | 4467.72533749845 | &#91;4368.85, 4529.6&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 262.0 | 262.0 | &#91;262, 262&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 1.0 | 1.0 | &#91;1, 1&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.02665 | 0.02665 | &#91;0.02385, 0.02945&#93; |

## trace -> enforce_context: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | 4829.115550001006 | 4829.115550001006 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 262.0 | 262.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 1.0 | 1.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 0.02395 | 0.02395 | insufficient tasks |

## trace -> shadow_budget: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 68.78018749830517 | 68.78018749830517 | &#91;43.0292, 90.9629&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.3882 | 1.3882 | &#91;0.89725, 2.26305&#93; |

## trace -> shadow_budget: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | 36.979449996579206 | 36.979449996579206 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 1.6546999999999998 | 1.6546999999999998 | insufficient tasks |

## trace -> shadow_combined: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | 9.665174998190196 | 9.665174998190196 | &#91;-0.330788, 22.4813&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 1.0402624999999999 | 1.0402624999999999 | &#91;0.850767, 1.2127&#93; |

## trace -> shadow_combined: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | -26.480000000447035 | -26.480000000447035 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 0.8035 | 0.8035 | insufficient tasks |

## trace -> shadow_context: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 8 | 0 / 0 / 4 | unavailable | unavailable | insufficient tasks |
| latency_ms | 8 / 8 / 8 | 4 / 4 / 4 | -18.07471250049275 | -18.07471250049275 | &#91;-64.773, 13.364&#93; |
| tokens | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 8 / 8 / 8 | 4 / 4 / 4 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 8 / 8 / 8 | 4 / 4 / 4 | 0.01355 | 0.01355 | &#91;0.0130866, 0.0142875&#93; |

## trace -> shadow_context: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| quality_score | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| provider_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 2 | 0 / 0 / 1 | unavailable | unavailable | insufficient tasks |
| latency_ms | 2 / 2 / 2 | 1 / 1 / 1 | -29.92525000081514 | -29.92525000081514 | insufficient tasks |
| tokens | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| model_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| tool_calls | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| retries | 2 / 2 / 2 | 1 / 1 / 1 | 0.0 | 0.0 | insufficient tasks |
| policy_eval_ms | 2 / 2 / 2 | 1 / 1 / 1 | 0.0167 | 0.0167 | insufficient tasks |

Full JSON retains every observation, protocol deviation, stop reason, duplicate/missing pair, metric denominator and task-level interval.
