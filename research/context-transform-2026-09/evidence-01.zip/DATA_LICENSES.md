# Attribution

Wine Quality: Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009). Wine Quality [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56S3T . Licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Original red and white CSV files are retained; the tool normalizes column names and adds color in memory. Study questions and reference SQL are original to this experiment.

AgentLoop and study code are Apache-2.0; see LICENSE. Dataset rights remain separate. Local model weights, inference binaries and dependency implementations are not redistributed.
