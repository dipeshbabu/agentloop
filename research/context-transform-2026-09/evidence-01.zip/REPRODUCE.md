# Reproduce the optional context summary study

All 80 planned observations are retained: 16 pilot and 64 held-out observations. All final answers met their frozen criteria. Summary enforcement reduced final-call input but added 262 total tokens and one call per pair; retain this resource regression. Costs remain unavailable; paid-provider spend was zero. See CASE_STUDY.md and study/report/ for full metrics and limitations.

Start from a full AgentLoop checkout at 320b47e6a72857359e556d127f749503a466f3ea. Overlay every file in source/ onto that checkout, preserving bytes. These snapshots are not an independently installable distribution. The measured runner uses CRLF line endings; repository formatters may normalize them, so use the archived bytes for original-hash verification. No code from the archive is executed by the archive reader.

With the matching checkout and source overlay, recompute without inference:

    python -m examples.context_study.runner --plan PATH_TO_UNPACKED/study/plan.json --export NEW_REPORT_DIRECTORY

The exporter verifies frozen code/data, slot identity, independent quality, model usage, trace hashes and matching policy/context receipts, then calls native study/ablation reporters. Missing/cancelled cases cannot improve the denominator. There is no invented recommendation-estimator attribution.

For new measurements, prepare a fresh protocol with examples.context_study.protocol --out NEW_ROOT --sources study/sources. Use Qwen3-4B-Instruct-2507-Q4_K_M from unsloth/Qwen3-4B-Instruct-2507-GGUF revision a06e946bb6b655725eafa393f4a9745d460374c9, SHA-256 3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597. The official llama.cpp b10964 Windows Vulkan zip has SHA-256 1ee3ad952f4ba71f438bd6d7bebef19e1c7af04adcaa35d08b4ddabb27d4c642.

    llama-server --model MODEL_FILE --host 127.0.0.1 --port 8766 --ctx-size 4096 --n-gpu-layers 99 --threads 6 --batch-size 256 --ubatch-size 128 --parallel 1 --metrics --cors-origins localhost --no-cors-credentials --no-webui --no-cache-prompt

Wait for /health, retain a fixed readiness warmup outside the experiment, then explicitly run examples.context_study.runner --plan NEW_ROOT/plan.json --model-file MODEL_FILE --execute. The frozen schedule balances condition order; database, request, usage and harness state reset for every observation. No observations execute concurrently. Summary and main calls share budgets and all their tokens/time remain included.

retired-setup/ retains the earlier interrupted preparation and warmup; it contains no task attempts and is outside the final cohort. No final task artifacts are redacted. Server console logs and model/runtime binaries are excluded. No result authorizes production activation or universal semantic-compression claims.
