# Attribution

UCI Wine Quality: Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009), Wine Quality [Dataset], UCI Machine Learning Repository, https://doi.org/10.24432/C56S3T . Licensed CC BY 4.0, https://creativecommons.org/licenses/by/4.0/ . Original red/white CSV bytes are retained; the tool normalizes columns and adds color in memory. These nine questions and reference SQL are study-authored and differ from the prior model-routing study.

AgentLoop and study code are Apache-2.0; see LICENSE. Dataset rights remain separate. Model weights and inference binaries are not redistributed.
