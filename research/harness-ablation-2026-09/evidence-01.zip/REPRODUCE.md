# Reproduce the real harness ablation

All 108 planned observations, including 18 stopped negative-control attempts, are retained. There are 90 native traces; the uninstrumented arm has host receipts and no fabricated trace. All costs remain unavailable self-hosted costs; paid-provider spend was zero.

Use AgentLoop core source revision 009c8a475265c41491e47aed002a3d67597e9723 with the included study code. The plan pins hashes for each relevant core/agent/runner/scorer file, source CSVs, model, configuration and environment. The core snapshot files in source/ are evidence, not a complete independently installable distribution; obtain the full core checkout at the recorded revision. Overlay the included examples/ packages there when reproducing the runner/exporter. A changed implementation or task needs a new protocol.

To recompute without model calls, run examples/real_harness_study/export.py --plan study/plan.json --out NEW_DIRECTORY from that matching checkout. It rechecks original host observations, independent grades, trace/diagnosis hashes and native policy evidence, then calls AgentLoop's native ablation and study exporters. No recommendation-based ledger entry is invented for count-only safety policies.

For new runs, prepare a fresh root with protocol.py --out NEW_ROOT --sources study/sources. The model is Qwen3-4B-Instruct-2507-Q4_K_M from unsloth/Qwen3-4B-Instruct-2507-GGUF revision a06e946bb6b655725eafa393f4a9745d460374c9, SHA-256 3605803b982cb64aead44f6c1b2ae36e3acdb41d8e46c8a94c6533bc4c67e597. Use the official llama.cpp b10964 Windows Vulkan build (zip SHA-256 1ee3ad952f4ba71f438bd6d7bebef19e1c7af04adcaa35d08b4ddabb27d4c642).

    llama-server --model MODEL_FILE --host 127.0.0.1 --port 8766 --ctx-size 4096 --n-gpu-layers 99 --threads 6 --batch-size 256 --ubatch-size 128 --parallel 1 --metrics --cors-origins localhost --no-cors-credentials --no-webui --no-cache-prompt

Wait for /health and perform the separately retained fixed readiness warmup before executing runner.py --plan NEW_ROOT/plan.json --model-file MODEL_FILE --execute. Each task/condition resets database, messages and policy state. The schedule is counterbalanced; no conditions run concurrently. Model/server loading and database construction are outside timing; trace/harness setup and task execution are inside. The source code and plan specify exact call/output/time bounds and scoring criteria.

No outcomes or task traces are redacted. Server console logs and model/runtime binaries are excluded; the relevant source/build/configuration and usage evidence are retained. This small public-data study does not establish general policy benefit or authorize production activation.
