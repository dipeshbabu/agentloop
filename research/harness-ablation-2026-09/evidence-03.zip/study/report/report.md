# Ablation: Real SQL agent: tracing and count-policy ablations

Descriptive host observations, not causal identification. Intervals give equal weight to observed task means within each split/cache stratum; repetitions are not independent tasks. Missingness, selection, small task counts, order/carryover effects and scorer errors remain limitations. A frozen hash is not proof of preregistration or environment reset. Policy evaluation time is not end-to-end overhead. Synthetic fixtures are not empirical benefits.

Evidence: host-supplied study; permissions and execution require external verification.

Planned observations: 108; observed: 108; unplanned: 0.

Execution statuses: `{"completed": 90, "stopped": 18}`

Token completeness: `{"exact": 108}`

Cost completeness / basis: `[{"unknown": 108}, {"unknown": 108}]`

Stop reasons: `{"budget_limit": 18}`

Deltas are candidate minus baseline. Negative latency/cost deltas are reductions, not evidence of task success.

| Comparison | Split / cache | Planned | Quality accepted | Rejected | Indeterminate | Unmatched |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| off -&gt; trace (trace_overhead) | held_out / prompt_cache_disabled | 12 | 12 | 0 | 0 | 0 |
| off -&gt; trace (trace_overhead) | pilot / prompt_cache_disabled | 6 | 6 | 0 | 0 | 0 |
| shadow_1 -&gt; enforce_1 (enforcement_effect) | held_out / prompt_cache_disabled | 12 | 0 | 12 | 0 | 0 |
| shadow_1 -&gt; enforce_1 (enforcement_effect) | pilot / prompt_cache_disabled | 6 | 0 | 6 | 0 | 0 |
| trace -&gt; enforce_1 (total_policy_effect) | held_out / prompt_cache_disabled | 12 | 0 | 12 | 0 | 0 |
| trace -&gt; enforce_1 (total_policy_effect) | pilot / prompt_cache_disabled | 6 | 0 | 6 | 0 | 0 |
| shadow_2 -&gt; enforce_2 (enforcement_effect) | held_out / prompt_cache_disabled | 12 | 12 | 0 | 0 | 0 |
| shadow_2 -&gt; enforce_2 (enforcement_effect) | pilot / prompt_cache_disabled | 6 | 6 | 0 | 0 | 0 |
| trace -&gt; enforce_2 (total_policy_effect) | held_out / prompt_cache_disabled | 12 | 12 | 0 | 0 | 0 |
| trace -&gt; enforce_2 (total_policy_effect) | pilot / prompt_cache_disabled | 6 | 6 | 0 | 0 | 0 |
| trace -&gt; shadow_1 (policy_shadow_overhead) | held_out / prompt_cache_disabled | 12 | 12 | 0 | 0 | 0 |
| trace -&gt; shadow_1 (policy_shadow_overhead) | pilot / prompt_cache_disabled | 6 | 6 | 0 | 0 | 0 |
| trace -&gt; shadow_2 (policy_shadow_overhead) | held_out / prompt_cache_disabled | 12 | 12 | 0 | 0 | 0 |
| trace -&gt; shadow_2 (policy_shadow_overhead) | pilot / prompt_cache_disabled | 6 | 6 | 0 | 0 | 0 |

## off -> trace: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 12 / 12 | 6 / 6 / 6 | -288.8679833376955 | -288.8679833376955 | &#91;-912.496, 40.2213&#93; |
| tokens | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |

## off -> trace: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 6 / 6 | 3 / 3 / 3 | -11.810766671260353 | -11.810766671260353 | &#91;-40.0251, 7.55435&#93; |
| tokens | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |

## shadow_1 -> enforce_1: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 0 / 12 | 6 / 0 / 6 | -1.0 | unavailable | insufficient tasks |
| quality_score | 12 / 0 / 12 | 6 / 0 / 6 | -1.0 | unavailable | insufficient tasks |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 0 / 12 | 6 / 0 / 6 | -3478.5352416705186 | unavailable | insufficient tasks |
| tokens | 12 / 0 / 12 | 6 / 0 / 6 | -382.1666666666667 | unavailable | insufficient tasks |
| model_calls | 12 / 0 / 12 | 6 / 0 / 6 | -1.0 | unavailable | insufficient tasks |
| tool_calls | 12 / 0 / 12 | 6 / 0 / 6 | 0.0 | unavailable | insufficient tasks |
| retries | 12 / 0 / 12 | 6 / 0 / 6 | 0.0 | unavailable | insufficient tasks |
| policy_eval_ms | 12 / 0 / 12 | 6 / 0 / 6 | -0.3021416666666667 | unavailable | insufficient tasks |

## shadow_1 -> enforce_1: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 0 / 6 | 3 / 0 / 3 | -1.0 | unavailable | insufficient tasks |
| quality_score | 6 / 0 / 6 | 3 / 0 / 3 | -1.0 | unavailable | insufficient tasks |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 0 / 6 | 3 / 0 / 3 | -2744.990533331778 | unavailable | insufficient tasks |
| tokens | 6 / 0 / 6 | 3 / 0 / 3 | -340.6666666666667 | unavailable | insufficient tasks |
| model_calls | 6 / 0 / 6 | 3 / 0 / 3 | -1.0 | unavailable | insufficient tasks |
| tool_calls | 6 / 0 / 6 | 3 / 0 / 3 | 0.0 | unavailable | insufficient tasks |
| retries | 6 / 0 / 6 | 3 / 0 / 3 | 0.0 | unavailable | insufficient tasks |
| policy_eval_ms | 6 / 0 / 6 | 3 / 0 / 3 | -0.10973333333333339 | unavailable | insufficient tasks |

## trace -> enforce_1: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 0 / 12 | 6 / 0 / 6 | -1.0 | unavailable | insufficient tasks |
| quality_score | 12 / 0 / 12 | 6 / 0 / 6 | -1.0 | unavailable | insufficient tasks |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 0 / 12 | 6 / 0 / 6 | -2999.7599583330157 | unavailable | insufficient tasks |
| tokens | 12 / 0 / 12 | 6 / 0 / 6 | -382.1666666666667 | unavailable | insufficient tasks |
| model_calls | 12 / 0 / 12 | 6 / 0 / 6 | -1.0 | unavailable | insufficient tasks |
| tool_calls | 12 / 0 / 12 | 6 / 0 / 6 | 0.0 | unavailable | insufficient tasks |
| retries | 12 / 0 / 12 | 6 / 0 / 6 | 0.0 | unavailable | insufficient tasks |
| policy_eval_ms | 12 / 0 / 12 | 6 / 0 / 6 | 1.8702500000000002 | unavailable | insufficient tasks |

## trace -> enforce_1: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 0 / 6 | 3 / 0 / 3 | -1.0 | unavailable | insufficient tasks |
| quality_score | 6 / 0 / 6 | 3 / 0 / 3 | -1.0 | unavailable | insufficient tasks |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 0 / 6 | 3 / 0 / 3 | -2747.433116666798 | unavailable | insufficient tasks |
| tokens | 6 / 0 / 6 | 3 / 0 / 3 | -340.6666666666667 | unavailable | insufficient tasks |
| model_calls | 6 / 0 / 6 | 3 / 0 / 3 | -1.0 | unavailable | insufficient tasks |
| tool_calls | 6 / 0 / 6 | 3 / 0 / 3 | 0.0 | unavailable | insufficient tasks |
| retries | 6 / 0 / 6 | 3 / 0 / 3 | 0.0 | unavailable | insufficient tasks |
| policy_eval_ms | 6 / 0 / 6 | 3 / 0 / 3 | 1.5512833333333333 | unavailable | insufficient tasks |

## shadow_2 -> enforce_2: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 12 / 12 | 6 / 6 / 6 | 38.42041666454558 | 38.42041666454558 | &#91;-61.9254, 191.221&#93; |
| tokens | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 12 / 12 / 12 | 6 / 6 / 6 | -0.33450833333333335 | -0.33450833333333335 | &#91;-0.686167, -0.00846333&#93; |

## shadow_2 -> enforce_2: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 6 / 6 | 3 / 3 / 3 | -13.011716665156806 | -13.011716665156806 | &#91;-21.8748, -7.44185&#93; |
| tokens | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 6 / 6 / 6 | 3 / 3 / 3 | -0.4772666666666667 | -0.4772666666666667 | &#91;-0.70625, -0.303&#93; |

## trace -> enforce_2: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 12 / 12 | 6 / 6 / 6 | 431.82523333355977 | 431.82523333355977 | &#91;-17.0266, 1285.45&#93; |
| tokens | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 12 / 12 / 12 | 6 / 6 / 6 | 1.951325 | 1.951325 | &#91;1.86492, 2.0345&#93; |

## trace -> enforce_2: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 6 / 6 | 3 / 3 / 3 | 6.900383336566544 | 6.900383336566544 | &#91;-21.0163, 30.226&#93; |
| tokens | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 6 / 6 / 6 | 3 / 3 / 3 | 1.5403166666666666 | 1.5403166666666666 | &#91;1.3749, 1.68085&#93; |

## trace -> shadow_1: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 12 / 12 | 6 / 6 / 6 | 478.7752833375028 | 478.7752833375028 | &#91;-29.9987, 1339.95&#93; |
| tokens | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 12 / 12 / 12 | 6 / 6 / 6 | 2.1723916666666665 | 2.1723916666666665 | &#91;1.78874, 2.79728&#93; |

## trace -> shadow_1: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 6 / 6 | 3 / 3 / 3 | -2.442583335020269 | -2.442583335020269 | &#91;-19.6662, 7.2719&#93; |
| tokens | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 6 / 6 / 6 | 3 / 3 / 3 | 1.6610166666666668 | 1.6610166666666668 | &#91;1.42005, 1.85555&#93; |

## trace -> shadow_2: held_out / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 12 | 0 / 0 / 6 | unavailable | unavailable | insufficient tasks |
| latency_ms | 12 / 12 / 12 | 6 / 6 / 6 | 393.4048166690142 | 393.4048166690142 | &#91;1.71058, 1108.88&#93; |
| tokens | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 12 / 12 / 12 | 6 / 6 / 6 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 12 / 12 / 12 | 6 / 6 / 6 | 2.285833333333333 | 2.285833333333333 | &#91;1.92703, 2.70185&#93; |

## trace -> shadow_2: pilot / prompt_cache_disabled

Means give equal weight to evaluable tasks. Quality-preserving columns exclude rejected/indeterminate pairs; the planned denominator above still includes them.

| Metric | Pairs: known / quality-eligible / planned | Tasks: known / quality-eligible / planned | Descriptive mean delta | Quality-preserving mean delta | Task interval (quality-preserving) |
| --- | ---: | ---: | ---: | ---: | --- |
| success | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| quality_score | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| provider_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| calculated_cost_usd | 0 / 0 / 6 | 0 / 0 / 3 | unavailable | unavailable | insufficient tasks |
| latency_ms | 6 / 6 / 6 | 3 / 3 / 3 | 19.91210000172335 | 19.91210000172335 | &#91;-13.5745, 39.9446&#93; |
| tokens | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| model_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| tool_calls | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| retries | 6 / 6 / 6 | 3 / 3 / 3 | 0.0 | 0.0 | &#91;0, 0&#93; |
| policy_eval_ms | 6 / 6 / 6 | 3 / 3 / 3 | 2.017583333333333 | 2.017583333333333 | &#91;1.79745, 2.3871&#93; |

Full JSON retains every observation, protocol deviation, stop reason, duplicate/missing pair, metric denominator and task-level interval.
