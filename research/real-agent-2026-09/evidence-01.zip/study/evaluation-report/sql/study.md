# Study: Exploratory sql routing

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| quality_score | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| runtime_ms | 12 | 0 | 4245.88 | 3856.49 | 3543.14 | 6011.97 | not requested |
| input_tokens | 12 | 0 | 602.5 | 594 | 574 | 659 | not requested |
| output_tokens | 12 | 0 | 55.5 | 53 | 41 | 85 | not requested |
| model_call_count | 12 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{}`
Success basis: `{"task_metadata_and_execution": 12}`

## Condition: candidate

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0.666667 | 1 | 0 | 1 | not requested |
| quality_score | 12 | 0 | 0.666667 | 1 | 0 | 1 | not requested |
| runtime_ms | 12 | 0 | 1829.29 | 1656.87 | 1409.28 | 2743.35 | not requested |
| input_tokens | 12 | 0 | 601.667 | 593 | 573 | 657 | not requested |
| output_tokens | 12 | 0 | 52.3333 | 50 | 40 | 78 | not requested |
| model_call_count | 12 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 4}`
Success basis: `{"task_metadata_and_execution": 12}`

## Paired comparison: candidate

Matched pairs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | -0.333333 | 0 | -1 | 0 | 95.0%: &#91;-0.583333, -0.0833333&#93; |
| quality_score | 12 | 0 | -0.333333 | 0 | -1 | 0 | 95.0%: &#91;-0.583333, -0.0833333&#93; |
| runtime_ms | 12 | 0 | -2416.58 | -2238.56 | -4050.51 | -1444.41 | 95.0%: &#91;-3054.91, -1973.87&#93; |
| input_tokens | 12 | 0 | -0.833333 | -1 | -2 | 1 | 95.0%: &#91;-1.25, -0.333333&#93; |
| output_tokens | 12 | 0 | -3.16667 | -3 | -7 | -1 | 95.0%: &#91;-4.33542, -2.08333&#93; |
| model_call_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| tool_call_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | insufficient pairs |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
