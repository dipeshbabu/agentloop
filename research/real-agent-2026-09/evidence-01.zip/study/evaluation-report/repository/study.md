# Study: Exploratory repository routing

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| quality_score | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| runtime_ms | 12 | 0 | 6762.54 | 6815.11 | 6038.15 | 7727.39 | not requested |
| input_tokens | 12 | 0 | 1280.83 | 1278 | 1270 | 1303 | not requested |
| output_tokens | 12 | 0 | 59 | 58.5 | 50 | 71 | not requested |
| model_call_count | 12 | 0 | 4 | 4 | 4 | 4 | not requested |
| tool_call_count | 12 | 0 | 4 | 4 | 4 | 4 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 12}`
Success basis: `{"task_metadata_and_execution": 12}`

## Condition: candidate

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| quality_score | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| runtime_ms | 12 | 0 | 1695.48 | 1694.78 | 980.232 | 2225.29 | not requested |
| input_tokens | 12 | 0 | 514.833 | 562.5 | 263 | 571 | not requested |
| output_tokens | 12 | 0 | 58.5 | 58 | 41 | 78 | not requested |
| model_call_count | 12 | 0 | 1.83333 | 2 | 1 | 2 | not requested |
| tool_call_count | 12 | 0 | 0.833333 | 1 | 0 | 1 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 12}`
Success basis: `{"task_metadata_and_execution": 12}`

## Paired comparison: candidate

Matched pairs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| quality_score | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| runtime_ms | 12 | 0 | -5067.06 | -4847.28 | -6676.94 | -3987 | 95.0%: &#91;-5705.87, -4570.62&#93; |
| input_tokens | 12 | 0 | -766 | -715.5 | -1012 | -709 | 95.0%: &#91;-838.673, -715.165&#93; |
| output_tokens | 12 | 0 | -0.5 | 5.5 | -24 | 15 | 95.0%: &#91;-8.00208, 7&#93; |
| model_call_count | 12 | 0 | -2.16667 | -2 | -3 | -2 | 95.0%: &#91;-2.41667, -2&#93; |
| tool_call_count | 12 | 0 | -3.16667 | -3 | -4 | -3 | 95.0%: &#91;-3.41667, -3&#93; |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | insufficient pairs |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
