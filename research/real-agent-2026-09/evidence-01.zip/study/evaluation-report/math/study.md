# Study: Exploratory math routing

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0.333333 | 0 | 0 | 1 | not requested |
| quality_score | 12 | 0 | 0.333333 | 0 | 0 | 1 | not requested |
| runtime_ms | 12 | 0 | 3367.14 | 3298.16 | 3004.77 | 3901.24 | not requested |
| input_tokens | 12 | 0 | 528.667 | 519.5 | 478 | 601 | not requested |
| output_tokens | 12 | 0 | 39.8333 | 39 | 36 | 46 | not requested |
| model_call_count | 12 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 8}`
Success basis: `{"task_metadata_and_execution": 12}`

## Condition: candidate

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0.333333 | 0 | 0 | 1 | not requested |
| quality_score | 12 | 0 | 0.333333 | 0 | 0 | 1 | not requested |
| runtime_ms | 12 | 0 | 1493.17 | 1427.31 | 1227.19 | 1829.52 | not requested |
| input_tokens | 12 | 0 | 526.833 | 514.5 | 486 | 599 | not requested |
| output_tokens | 12 | 0 | 36.6667 | 38 | 27 | 44 | not requested |
| model_call_count | 12 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 8}`
Success basis: `{"task_metadata_and_execution": 12}`

## Paired comparison: candidate

Matched pairs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0 | 0 | -1 | 1 | 95.0%: &#91;-0.333333, 0.333333&#93; |
| quality_score | 12 | 0 | 0 | 0 | -1 | 1 | 95.0%: &#91;-0.333333, 0.333333&#93; |
| runtime_ms | 12 | 0 | -1873.96 | -1974.41 | -2168.34 | -1447.98 | 95.0%: &#91;-2019.91, -1717.98&#93; |
| input_tokens | 12 | 0 | -1.83333 | -2.5 | -7 | 8 | 95.0%: &#91;-4.25, 1.08333&#93; |
| output_tokens | 12 | 0 | -3.16667 | -3.5 | -9 | 4 | 95.0%: &#91;-5.25208, -0.666667&#93; |
| model_call_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| tool_call_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | insufficient pairs |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
