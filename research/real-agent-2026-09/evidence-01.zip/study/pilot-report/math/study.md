# Study: Exploratory math routing

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| quality_score | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| runtime_ms | 2 | 0 | 2925.22 | 2925.22 | 2920.92 | 2929.52 | not requested |
| input_tokens | 2 | 0 | 514 | 514 | 514 | 514 | not requested |
| output_tokens | 2 | 0 | 35 | 35 | 33.2 | 36.8 | not requested |
| model_call_count | 2 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{}`
Success basis: `{"task_metadata_and_execution": 2}`

## Condition: candidate

Runs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 0.5 | 0.5 | 0.05 | 0.95 | not requested |
| quality_score | 2 | 0 | 0.5 | 0.5 | 0.05 | 0.95 | not requested |
| runtime_ms | 2 | 0 | 1201.74 | 1201.74 | 1199.05 | 1204.43 | not requested |
| input_tokens | 2 | 0 | 510 | 510 | 506.4 | 513.6 | not requested |
| output_tokens | 2 | 0 | 30 | 30 | 28.2 | 31.8 | not requested |
| model_call_count | 2 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 1}`
Success basis: `{"task_metadata_and_execution": 2}`

## Paired comparison: candidate

Matched pairs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | -0.5 | -0.5 | -0.95 | -0.05 | 95.0%: &#91;-1, 0&#93; |
| quality_score | 2 | 0 | -0.5 | -0.5 | -0.95 | -0.05 | 95.0%: &#91;-1, 0&#93; |
| runtime_ms | 2 | 0 | -1723.48 | -1723.48 | -1725.09 | -1721.86 | 95.0%: &#91;-1725.27, -1721.68&#93; |
| input_tokens | 2 | 0 | -4 | -4 | -7.6 | -0.4 | 95.0%: &#91;-8, 0&#93; |
| output_tokens | 2 | 0 | -5 | -5 | -8.6 | -1.4 | 95.0%: &#91;-9, -1&#93; |
| model_call_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| tool_call_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | insufficient pairs |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
