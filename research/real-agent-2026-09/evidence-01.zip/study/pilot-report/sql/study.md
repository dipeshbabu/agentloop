# Study: Exploratory sql routing

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| quality_score | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| runtime_ms | 2 | 0 | 3621.62 | 3621.62 | 3555.1 | 3688.14 | not requested |
| input_tokens | 2 | 0 | 585 | 585 | 579.6 | 590.4 | not requested |
| output_tokens | 2 | 0 | 45 | 45 | 42.3 | 47.7 | not requested |
| model_call_count | 2 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{}`
Success basis: `{"task_metadata_and_execution": 2}`

## Condition: candidate

Runs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| quality_score | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| runtime_ms | 2 | 0 | 1475.32 | 1475.32 | 1437.03 | 1513.61 | not requested |
| input_tokens | 2 | 0 | 582 | 582 | 572.1 | 591.9 | not requested |
| output_tokens | 2 | 0 | 40 | 40 | 36.4 | 43.6 | not requested |
| model_call_count | 2 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{}`
Success basis: `{"task_metadata_and_execution": 2}`

## Paired comparison: candidate

Matched pairs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| quality_score | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| runtime_ms | 2 | 0 | -2146.3 | -2146.3 | -2251.12 | -2041.49 | 95.0%: &#91;-2262.76, -2029.84&#93; |
| input_tokens | 2 | 0 | -3 | -3 | -7.5 | 1.5 | 95.0%: &#91;-8, 2&#93; |
| output_tokens | 2 | 0 | -5 | -5 | -5.9 | -4.1 | 95.0%: &#91;-6, -4&#93; |
| model_call_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| tool_call_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | insufficient pairs |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
