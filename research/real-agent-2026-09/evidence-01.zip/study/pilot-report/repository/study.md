# Study: Exploratory repository routing

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| quality_score | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| runtime_ms | 2 | 0 | 6440.12 | 6440.12 | 6233.46 | 6646.79 | not requested |
| input_tokens | 2 | 0 | 1288 | 1288 | 1279 | 1297 | not requested |
| output_tokens | 2 | 0 | 68 | 68 | 67.1 | 68.9 | not requested |
| model_call_count | 2 | 0 | 4 | 4 | 4 | 4 | not requested |
| tool_call_count | 2 | 0 | 4 | 4 | 4 | 4 | not requested |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 2}`
Success basis: `{"task_metadata_and_execution": 2}`

## Condition: candidate

Runs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| quality_score | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| runtime_ms | 2 | 0 | 1615.11 | 1615.11 | 1524.67 | 1705.56 | not requested |
| input_tokens | 2 | 0 | 580.5 | 580.5 | 559.35 | 601.65 | not requested |
| output_tokens | 2 | 0 | 57 | 57 | 56.1 | 57.9 | not requested |
| model_call_count | 2 | 0 | 2 | 2 | 2 | 2 | not requested |
| tool_call_count | 2 | 0 | 1 | 1 | 1 | 1 | not requested |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 2}`
Success basis: `{"task_metadata_and_execution": 2}`

## Paired comparison: candidate

Matched pairs: 2

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| quality_score | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| runtime_ms | 2 | 0 | -4825.01 | -4825.01 | -4941.24 | -4708.79 | 95.0%: &#91;-4954.15, -4695.87&#93; |
| input_tokens | 2 | 0 | -707.5 | -707.5 | -719.65 | -695.35 | 95.0%: &#91;-721, -694&#93; |
| output_tokens | 2 | 0 | -11 | -11 | -11 | -11 | 95.0%: &#91;-11, -11&#93; |
| model_call_count | 2 | 0 | -2 | -2 | -2 | -2 | 95.0%: &#91;-2, -2&#93; |
| tool_call_count | 2 | 0 | -3 | -3 | -3 | -3 | 95.0%: &#91;-3, -3&#93; |
| retry_count | 2 | 0 | 0 | 0 | 0 | 0 | 95.0%: &#91;0, 0&#93; |
| cost_usd | 0 | 2 | unavailable | unavailable | unavailable | unavailable | insufficient pairs |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
