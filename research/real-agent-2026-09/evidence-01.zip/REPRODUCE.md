# Reproduce this study

The original results are readable JSON and standalone HTML under study/. All 72 held-out attempts, 12 revised pilot attempts, six untraced controls, and six initial onboarding failures are retained. The initial pilot's six candidate slots were not run. See onboarding-v1/disposition.json. No task traces or outcomes were redacted. Model weights/binaries and server console logs are not included; installation paths are omitted from environment.json.

Install requirements-frozen.txt into a separate environment. Use its Python with -I and implementation/real_agent_study/results.py report --protocol study/evaluation-frozen.json --root study --out NEW_REPORT_DIRECTORY to recompute reports without inference. Code and source hashes must match the frozen protocol.

For new real runs, copy the sources and protocol into a fresh study root without runs/. Download the two GGUF files from their pinned Hugging Face repositories/revisions in the protocol and verify their SHA-256. Use the official llama.cpp b10964 Windows Vulkan runtime (zip SHA-256 1ee3ad952f4ba71f438bd6d7bebef19e1c7af04adcaa35d08b4ddabb27d4c642), https://github.com/ggml-org/llama.cpp/releases/tag/b10964 . The server command for each model is:

    llama-server --model MODEL_FILE --host 127.0.0.1 --port 8766 --ctx-size 4096 --n-gpu-layers 99 --threads 6 --batch-size 256 --ubatch-size 128 --parallel 1 --metrics --cors-origins localhost --no-cors-credentials --no-webui --no-cache-prompt

Run one server at a time. Wait for /health, perform the separately retained fixed readiness warmup, then run:

    STUDY_PYTHON -I implementation/real_agent_study/run.py run --protocol study/evaluation-frozen.json --root study --condition baseline --split evaluation --repetition 0 --model-file MODEL_FILE --execute

Switch to the candidate server and repeat with --condition candidate. Repeat baseline then candidate for repetition 1. The runner verifies model identity, source/code hashes, and archived baseline predictions before allowing candidates. Never overwrite original attempts. Use pilot-frozen.json and --split pilot for the separate pilot; --untraced disables span capture for the baseline controls. Public task labels are withheld from agent input. Any implementation, task, model, scorer, or configuration change requires a new protocol and renewed evaluation.

Costs are unavailable self-hosted operating costs, not invented zero-dollar measurements. Paid-provider spend was zero. Timing excludes server startup, data/framework setup, final export and analysis. Fixed condition order, shared hardware, public benchmark contamination and small task counts limit interpretation. Preserve failures, unavailable values, and planned denominators when reusing these artifacts.
