# Data and software sources

AgentLoop source and study code: Apache-2.0; see LICENSE. Dataset licenses below remain separate.

UCI Wine Quality: Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009). Wine Quality [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56S3T . Licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Original CSV bytes are retained. The study tool normalizes column names and adds red/white color in memory. Questions and reference SQL are study-authored.

GSM8K: copyright (c) 2021 OpenAI, MIT. See study/sources/gsm8k-LICENSE.txt for the full license; source revision and SHA-256 are in the protocol. Task-file bytes are unchanged. Selected indices and final-answer extraction are identified in the tasks and source code.

Model weights, llama.cpp binaries and dependency code are not redistributed. Their revisions, licenses and download locations are documented in the protocols and repository case study. Published outcomes are exploratory; they do not authorize a deployment or establish population precision.
