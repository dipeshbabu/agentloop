from agentloop.autoinstrument import (
    DetectionResult,
    InstrumentationResult,
    auto_instrument,
    detect_integrations,
    instrument,
)
from agentloop.client import AgentLoopClient, AgentLoopClientError
from agentloop.decorators import trace_model, trace_tool, traceable
from agentloop.doctor import run_doctor
from agentloop.findings import build_diagnosis
from agentloop.judgment_types import (
    JudgeIdentity,
    JudgeUsage,
    JudgmentAnswer,
    JudgmentBackend,
    JudgmentEvidence,
    JudgmentRequest,
    JudgmentSpec,
    JudgmentUncertainty,
)
from agentloop.judgments import (
    JudgmentSession,
    LocalCallbackJudge,
    attach_judgment,
    judgment_request,
    read_judgments,
)
from agentloop.otel import trace_from_otel, trace_to_otel, traces_from_otel
from agentloop.patches import RepositoryPathError, build_patch_plan
from agentloop.replay import ReplayGates, build_replay_report
from agentloop.retention import RetentionContext, RetentionPolicy, RetentionSession, read_retention
from agentloop.runtime import (
    CLEAR,
    FinalizationError,
    get_last_error,
    get_runtime_config,
    init,
    reset_runtime,
)
from agentloop.semantic_waste import evaluate_semantic_waste, read_semantic_waste
from agentloop.semantic_waste_types import SemanticInvestigation
from agentloop.structured_quality import attach_quality_report
from agentloop.tracer import (
    AgentTrace,
    bind_trace_context,
    current_trace,
    record_model_call,
    record_tool_call,
    trace_agent,
    trace_model_call,
    trace_retry,
    trace_tool_call,
)
from agentloop.value import build_value_report
from agentloop.version import __version__
from agentloop.workflows import (
    ExecutionTrace,
    StageInfo,
    WorkflowInfo,
    operation_metadata,
    record_operation,
    set_workflow_outcome,
    trace_operation,
    trace_workflow,
    workflow_metadata,
)

__all__ = [
    "SemanticInvestigation",
    "evaluate_semantic_waste",
    "read_semantic_waste",
    "JudgeIdentity",
    "JudgeUsage",
    "JudgmentAnswer",
    "JudgmentBackend",
    "JudgmentEvidence",
    "JudgmentRequest",
    "JudgmentSpec",
    "JudgmentUncertainty",
    "JudgmentSession",
    "LocalCallbackJudge",
    "attach_judgment",
    "judgment_request",
    "read_judgments",
    "AgentLoopClient",
    "AgentLoopClientError",
    "AgentTrace",
    "attach_quality_report",
    "ExecutionTrace",
    "StageInfo",
    "WorkflowInfo",
    "operation_metadata",
    "record_operation",
    "set_workflow_outcome",
    "trace_operation",
    "trace_workflow",
    "workflow_metadata",
    "CLEAR",
    "FinalizationError",
    "DetectionResult",
    "InstrumentationResult",
    "ReplayGates",
    "RetentionContext",
    "RetentionPolicy",
    "RetentionSession",
    "read_retention",
    "RepositoryPathError",
    "auto_instrument",
    "bind_trace_context",
    "detect_integrations",
    "instrument",
    "build_value_report",
    "build_diagnosis",
    "build_patch_plan",
    "build_replay_report",
    "current_trace",
    "get_last_error",
    "get_runtime_config",
    "init",
    "record_model_call",
    "record_tool_call",
    "reset_runtime",
    "run_doctor",
    "trace_agent",
    "trace_from_otel",
    "traces_from_otel",
    "trace_model",
    "trace_model_call",
    "trace_tool",
    "trace_tool_call",
    "trace_retry",
    "traceable",
    "trace_to_otel",
    "__version__",
]
