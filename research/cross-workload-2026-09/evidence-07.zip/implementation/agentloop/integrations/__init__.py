"""Optional integrations for external agent frameworks."""
