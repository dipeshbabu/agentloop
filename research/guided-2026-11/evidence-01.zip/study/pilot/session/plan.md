# Guided pilot

Review the baseline recommendations, apply one change, and capture the same task set again.

Investigation focus is parallelize_tools.
The measured objective is latency. Every baseline and candidate output must pass its declared quality checks.

## repository-retry, repetition 0

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_repository&#96; tool calls | declared | unknown | 0.346 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 322.779 | needs_evidence_or_review |

### Parallelize repeated &#96;read_repository&#96; tool calls

Confidence is medium.

Affected spans

evt_14fdbc1956894d3a, evt_5466faec3be3435c, evt_672fb4dd30114698

Observed evidence

```json
[
  {
    "span_id": "evt_14fdbc1956894d3a",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.16,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_5466faec3be3435c",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.186,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_672fb4dd30114698",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.325,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.6704000988975167,
      "max_duration_ms": 0.32460002694278955,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.346,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## retrieval-retry, repetition 0

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_retrieval&#96; tool calls | declared | unknown | 0.032 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 483.692 | needs_evidence_or_review |

### Parallelize repeated &#96;read_retrieval&#96; tool calls

Confidence is medium.

Affected spans

evt_04dc87dc3f144f98, evt_57ddb9799f9b450a, evt_66ee3e9b16354f57

Observed evidence

```json
[
  {
    "span_id": "evt_04dc87dc3f144f98",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.017,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_57ddb9799f9b450a",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.02,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_66ee3e9b16354f57",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.015,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.051299924962222576,
      "max_duration_ms": 0.019699917174875736,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.032,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## workflow-small, repetition 0

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_workflow&#96; tool calls | declared | unknown | 0.044 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 628.17 | needs_evidence_or_review |

### Parallelize repeated &#96;read_workflow&#96; tool calls

Confidence is medium.

Affected spans

evt_9ce504e9e0bd4194, evt_d74c4058e1694cea, evt_e484b85da3014b6a

Observed evidence

```json
[
  {
    "span_id": "evt_9ce504e9e0bd4194",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.025,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_d74c4058e1694cea",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.031,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_e484b85da3014b6a",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.018,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.07450010161846876,
      "max_duration_ms": 0.03090000245720148,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.044,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```
