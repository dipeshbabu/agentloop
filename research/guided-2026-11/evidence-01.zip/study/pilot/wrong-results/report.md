# Guided pilot

The change did not pass the declared checks.

0 of 3 planned attempts passed.

Applied change

Deliberately incorrect negative control

## repository-retry, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- latency_regression: 3.65% regression &lt;= 0.00% allowed
- latency_improvement: -3.65% improvement &gt;= 0.00% required
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1293.056 | 1340.203 |
| Input tokens | 124 | 124 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 3.65% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -3.65% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed latency_regression: 3.65% regression &lt;= 0.00% allowed latency_improvement: -3.65% improvement &gt;= 0.00% required quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required The selected objective has no measured improvement |

## retrieval-retry, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1936.036 | 897.997 |
| Input tokens | 110 | 110 |
| Output tokens | 16 | 16 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 53.62% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## workflow-small, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 2589.375 | 1159.054 |
| Input tokens | 118 | 118 |
| Output tokens | 13 | 13 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 55.24% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

Measurements describe this task set and run order. Repeated runs and independent tasks are needed to assess variability.

Native trace snapshots, frozen findings, replay results, linked interventions and paired study data accompany this report.
