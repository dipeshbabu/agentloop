# Guided held_out

Review the baseline recommendations, apply one change, and capture the same task set again.

Investigation focus is parallelize_tools.
The measured objective is latency. Every baseline and candidate output must pass its declared quality checks.

## repository-cache, repetition 0

Independent baseline quality

The declared check passed with score 1.0. JSON subset matched

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_repository&#96; tool calls | declared | unknown | 0.237 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 225.027 | needs_evidence_or_review |

### Parallelize repeated &#96;read_repository&#96; tool calls

Confidence is medium.

Affected spans

evt_1d4373a3245e453d, evt_9a334359ec294c5e, evt_c9173a6804ad44f0

Observed evidence

```json
[
  {
    "span_id": "evt_1d4373a3245e453d",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.114,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_9a334359ec294c5e",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.124,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_c9173a6804ad44f0",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.215,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.45199994929134846,
      "max_duration_ms": 0.2148000057786703,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.237,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## repository-cache, repetition 1

Independent baseline quality

The declared check passed with score 1.0. JSON subset matched

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_repository&#96; tool calls | declared | unknown | 0.366 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 300.084 | needs_evidence_or_review |

### Parallelize repeated &#96;read_repository&#96; tool calls

Confidence is medium.

Affected spans

evt_1013c640316049e8, evt_5c1bbd025180444a, evt_837ce2da3ba645f5

Observed evidence

```json
[
  {
    "span_id": "evt_1013c640316049e8",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.205,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_5c1bbd025180444a",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.161,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_837ce2da3ba645f5",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.27,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.6354999495670199,
      "max_duration_ms": 0.269699958153069,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.366,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## repository-completed, repetition 0

Independent baseline quality

The declared check passed with score 1.0. JSON subset matched

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_repository&#96; tool calls | declared | unknown | 0.998 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 300.853 | needs_evidence_or_review |

### Parallelize repeated &#96;read_repository&#96; tool calls

Confidence is medium.

Affected spans

evt_20ee5d00bc38411d, evt_8b34605beff64f49, evt_b9095f692d994a85

Observed evidence

```json
[
  {
    "span_id": "evt_20ee5d00bc38411d",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.689,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_8b34605beff64f49",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.775,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_b9095f692d994a85",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.309,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 1.7728999955579638,
      "max_duration_ms": 0.77479996252805,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.998,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## repository-completed, repetition 1

Independent baseline quality

The declared check passed with score 1.0. JSON subset matched

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_repository&#96; tool calls | declared | unknown | 0.29 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 271.127 | needs_evidence_or_review |

### Parallelize repeated &#96;read_repository&#96; tool calls

Confidence is medium.

Affected spans

evt_a7d61606b9c04434, evt_efcb6b2c71404a82, evt_fb36c18548fa4653

Observed evidence

```json
[
  {
    "span_id": "evt_a7d61606b9c04434",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.159,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_efcb6b2c71404a82",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.33,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_fb36c18548fa4653",
    "name": "read_repository",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.132,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.6201000651344657,
      "max_duration_ms": 0.3298000665381551,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.29,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## retrieval-retention, repetition 0

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_retrieval&#96; tool calls | declared | unknown | 0.013 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 358.988 | needs_evidence_or_review |

### Parallelize repeated &#96;read_retrieval&#96; tool calls

Confidence is medium.

Affected spans

evt_71989d21853944f1, evt_c89a5dd425d14220, evt_de359e636d3a403d

Observed evidence

```json
[
  {
    "span_id": "evt_71989d21853944f1",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.008,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_c89a5dd425d14220",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.008,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_de359e636d3a403d",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.005,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.02119992859661579,
      "max_duration_ms": 0.00809994526207447,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.013,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## retrieval-retention, repetition 1

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_retrieval&#96; tool calls | declared | unknown | 0.015 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 295.727 | needs_evidence_or_review |

### Parallelize repeated &#96;read_retrieval&#96; tool calls

Confidence is medium.

Affected spans

evt_4f8fffe7603a4990, evt_c9910fb1871641ff, evt_c9db8fe4897b46f2

Observed evidence

```json
[
  {
    "span_id": "evt_4f8fffe7603a4990",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.009,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_c9910fb1871641ff",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.009,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_c9db8fe4897b46f2",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.007,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.024300068616867065,
      "max_duration_ms": 0.009200070053339005,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.015,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## retrieval-context, repetition 0

Independent baseline quality

The declared check passed with score 1.0. JSON subset matched

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_retrieval&#96; tool calls | declared | unknown | 0.018 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 312.415 | needs_evidence_or_review |

### Parallelize repeated &#96;read_retrieval&#96; tool calls

Confidence is medium.

Affected spans

evt_48736d09b0db49e4, evt_546b479a83a440db, evt_fed3e24e14bd46f5

Observed evidence

```json
[
  {
    "span_id": "evt_48736d09b0db49e4",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.008,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_546b479a83a440db",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.009,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_fed3e24e14bd46f5",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.018,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.03520003519952297,
      "max_duration_ms": 0.017600017599761486,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.018,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## retrieval-context, repetition 1

Independent baseline quality

The declared check passed with score 1.0. JSON subset matched

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_retrieval&#96; tool calls | declared | unknown | 0.035 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 1101.66 | needs_evidence_or_review |

### Parallelize repeated &#96;read_retrieval&#96; tool calls

Confidence is medium.

Affected spans

evt_32a5160efe734760, evt_4144d6d63d31486d, evt_6f96f395164b49c7

Observed evidence

```json
[
  {
    "span_id": "evt_32a5160efe734760",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.015,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_4144d6d63d31486d",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.02,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_6f96f395164b49c7",
    "name": "read_retrieval",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.095,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.12919993605464697,
      "max_duration_ms": 0.09460002183914185,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.035,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## workflow-pads, repetition 0

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_workflow&#96; tool calls | declared | unknown | 0.064 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 467.884 | needs_evidence_or_review |

### Parallelize repeated &#96;read_workflow&#96; tool calls

Confidence is medium.

Affected spans

evt_66e22a5ce60645c6, evt_a81152e5b94a45ac, evt_d9a9185b868f4a93

Observed evidence

```json
[
  {
    "span_id": "evt_66e22a5ce60645c6",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.03,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_a81152e5b94a45ac",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.04,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_d9a9185b868f4a93",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.034,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.10360009036958218,
      "max_duration_ms": 0.03990007098764181,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.064,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## workflow-pads, repetition 1

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_workflow&#96; tool calls | declared | unknown | 0.038 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 308.757 | needs_evidence_or_review |

### Parallelize repeated &#96;read_workflow&#96; tool calls

Confidence is medium.

Affected spans

evt_2b2f77e688914d53, evt_9042a4fde2b442d7, evt_d34e14d5947947b5

Observed evidence

```json
[
  {
    "span_id": "evt_2b2f77e688914d53",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.021,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_9042a4fde2b442d7",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.017,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_d34e14d5947947b5",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.026,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.06409990601241589,
      "max_duration_ms": 0.026099965907633305,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.038,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## workflow-books, repetition 0

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_workflow&#96; tool calls | declared | unknown | 0.031 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 313.844 | needs_evidence_or_review |

### Parallelize repeated &#96;read_workflow&#96; tool calls

Confidence is medium.

Affected spans

evt_00e629a5f0e349c7, evt_021984560adf44a2, evt_21f31e719ffd46cd

Observed evidence

```json
[
  {
    "span_id": "evt_00e629a5f0e349c7",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.014,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_021984560adf44a2",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.02,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_21f31e719ffd46cd",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.017,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.051200040616095066,
      "max_duration_ms": 0.02010003663599491,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.031,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```

## workflow-books, repetition 1

Independent baseline quality

The declared check failed with score 0.0. mismatched keys: answer

Ranked investigations

| Rank | Finding | Evidence | Quality risk | Estimated latency benefit (ms) | Readiness |
| --- | --- | --- | --- | --- | --- |
| 1 | Parallelize repeated &#96;read_workflow&#96; tool calls | declared | unknown | 0.034 | needs_evidence_or_review |
| 2 | Route &#96;agent_decision&#96; to a cheaper model | unknown | unknown | 270.935 | needs_evidence_or_review |

### Parallelize repeated &#96;read_workflow&#96; tool calls

Confidence is medium.

Affected spans

evt_431910d294614183, evt_a995c9cca11a4eeb, evt_d02167449ce347e4

Observed evidence

```json
[
  {
    "span_id": "evt_431910d294614183",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.013,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_a995c9cca11a4eeb",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.022,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  },
  {
    "span_id": "evt_d02167449ce347e4",
    "name": "read_workflow",
    "event_type": "tool_call",
    "operation_kind": "tool",
    "duration_ms": 0.027,
    "input_tokens": 0,
    "output_tokens": 0,
    "model": null,
    "status": "ok"
  }
]
```

Suggested change

After verifying output independence and shared-state safety, use asyncio.gather or ThreadPoolExecutor and validate the change with replay.

Estimated savings

The native estimator supplies a hypothesis to test. Measured candidate outcomes are recorded by finish.

```json
{
  "estimate": {
    "estimator_id": "parallelize_tools",
    "estimator_version": "1.0",
    "method": "heuristic",
    "confidence": "medium",
    "calibrated": false,
    "formula": "sum_duration_ms - max_duration_ms",
    "parameters": {},
    "inputs": {
      "sum_duration_ms": 0.06130000110715628,
      "max_duration_ms": 0.02719997428357601,
      "span_count": 3,
      "current_cost_usd": null,
      "repeated_context_ratio": 0.0,
      "cost_status": "unknown",
      "token_status": "exact"
    },
    "assumptions": [
      "No call consumes another call's output.",
      "Calls do not conflict through shared mutable state.",
      "Calls are on the runtime-limiting path and scheduling adds no overhead.",
      "The formula applies assuming concurrent execution has negligible scheduling overhead."
    ],
    "unmodeled_metrics": [
      "cost"
    ]
  },
  "predicted_effect": {
    "estimated_latency_savings_ms": 0.034,
    "estimated_cost_savings_usd": null,
    "formula": "sum_duration_ms - max_duration_ms"
  }
}
```

Missing evidence and review requirements

cost_opportunity_unavailable, missing_input:quality_risk, missing_input:reversible, missing_input:validation_cost_usd, missing_input:validation_effort_minutes

Validation and trade-offs

```json
{
  "checks": {
    "command": "agentloop replay",
    "acceptance_criteria": "runtime decreases while tool outputs remain equivalent"
  },
  "assumptions": [
    "No call consumes another call's output.",
    "Calls do not conflict through shared mutable state.",
    "Calls are on the runtime-limiting path and scheduling adds no overhead.",
    "The formula applies assuming concurrent execution has negligible scheduling overhead."
  ]
}
```
