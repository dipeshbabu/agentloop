# Guided held_out

The change did not pass the declared checks.

0 of 12 planned attempts passed.

Applied change

Deliberately incorrect negative control

## repository-cache, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 901.437 | 870.130 |
| Input tokens | 123 | 123 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 3.47% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## repository-cache, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1202.424 | 643.926 |
| Input tokens | 123 | 123 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 46.45% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## repository-completed, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1207.884 | 1094.562 |
| Input tokens | 120 | 120 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 9.38% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## repository-completed, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- latency_regression: 0.45% regression &lt;= 0.00% allowed
- latency_improvement: -0.45% improvement &gt;= 0.00% required
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1086.517 | 1091.390 |
| Input tokens | 120 | 120 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 0.45% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -0.45% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed latency_regression: 0.45% regression &lt;= 0.00% allowed latency_improvement: -0.45% improvement &gt;= 0.00% required quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required The selected objective has no measured improvement |

## retrieval-retention, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1437.065 | 1155.042 |
| Input tokens | 113 | 113 |
| Output tokens | 17 | 17 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 19.62% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## retrieval-retention, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1183.858 | 1080.832 |
| Input tokens | 113 | 113 |
| Output tokens | 17 | 17 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 8.70% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## retrieval-context, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1250.724 | 796.115 |
| Input tokens | 114 | 114 |
| Output tokens | 18 | 18 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 36.35% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## retrieval-context, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 4409.446 | 816.635 |
| Input tokens | 114 | 114 |
| Output tokens | 18 | 18 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 81.48% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## workflow-pads, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1906.579 | 877.921 |
| Input tokens | 118 | 118 |
| Output tokens | 13 | 13 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 53.95% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## workflow-pads, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1270.835 | 1101.874 |
| Input tokens | 118 | 118 |
| Output tokens | 13 | 13 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 13.30% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## workflow-books, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1270.974 | 1056.623 |
| Input tokens | 118 | 118 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 16.87% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## workflow-books, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1098.439 | 815.293 |
| Input tokens | 118 | 118 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 25.78% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

Measurements describe this task set and run order. Repeated runs and independent tasks are needed to assess variability.

Native trace snapshots, frozen findings, replay results, linked interventions and paired study data accompany this report.
