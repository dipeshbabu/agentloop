# Guided held_out

The change did not pass the declared checks.

3 of 12 planned attempts passed.

Applied change

Reuse immutable tool results within one request; unchanged prompt/model/tasks/scorer

## repository-cache, repetition 0

Rejected

- Native replay gates failed
- latency_regression: 27.32% regression &lt;= 0.00% allowed
- latency_improvement: -27.32% improvement &gt;= 0.00% required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 901.437 | 1147.730 |
| Input tokens | 123 | 123 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 1.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 27.32% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -27.32% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | passed | supplied quality fixtures passed |
| quality_score | passed | 1.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Native replay gates failed latency_regression: 27.32% regression &lt;= 0.00% allowed latency_improvement: -27.32% improvement &gt;= 0.00% required The selected objective has no measured improvement |

## repository-cache, repetition 1

Rejected

- Native replay gates failed
- latency_regression: 11.33% regression &lt;= 0.00% allowed
- latency_improvement: -11.33% improvement &gt;= 0.00% required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1202.424 | 1338.691 |
| Input tokens | 123 | 123 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 1.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 11.33% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -11.33% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | passed | supplied quality fixtures passed |
| quality_score | passed | 1.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Native replay gates failed latency_regression: 11.33% regression &lt;= 0.00% allowed latency_improvement: -11.33% improvement &gt;= 0.00% required The selected objective has no measured improvement |

## repository-completed, repetition 0

Rejected

- Native replay gates failed
- latency_regression: 45.70% regression &lt;= 0.00% allowed
- latency_improvement: -45.70% improvement &gt;= 0.00% required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1207.884 | 1759.925 |
| Input tokens | 120 | 120 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 1.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 45.70% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -45.70% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | passed | supplied quality fixtures passed |
| quality_score | passed | 1.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Native replay gates failed latency_regression: 45.70% regression &lt;= 0.00% allowed latency_improvement: -45.70% improvement &gt;= 0.00% required The selected objective has no measured improvement |

## repository-completed, repetition 1

Passed


| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1086.517 | 1025.429 |
| Input tokens | 120 | 120 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 1.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 5.62% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | passed | supplied quality fixtures passed |
| quality_score | passed | 1.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | passed | All guided execution, quality and measured-objective checks passed |

## retrieval-retention, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- latency_regression: 60.14% regression &lt;= 0.00% allowed
- latency_improvement: -60.14% improvement &gt;= 0.00% required
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1437.065 | 2301.357 |
| Input tokens | 113 | 113 |
| Output tokens | 17 | 17 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 60.14% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -60.14% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed latency_regression: 60.14% regression &lt;= 0.00% allowed latency_improvement: -60.14% improvement &gt;= 0.00% required quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required The selected objective has no measured improvement |

## retrieval-retention, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- latency_regression: 1.73% regression &lt;= 0.00% allowed
- latency_improvement: -1.73% improvement &gt;= 0.00% required
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1183.858 | 1204.378 |
| Input tokens | 113 | 113 |
| Output tokens | 17 | 17 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 1.73% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -1.73% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed latency_regression: 1.73% regression &lt;= 0.00% allowed latency_improvement: -1.73% improvement &gt;= 0.00% required quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required The selected objective has no measured improvement |

## retrieval-context, repetition 0

Passed


| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1250.724 | 1214.963 |
| Input tokens | 114 | 114 |
| Output tokens | 18 | 18 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 1.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 2.86% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | passed | supplied quality fixtures passed |
| quality_score | passed | 1.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | passed | All guided execution, quality and measured-objective checks passed |

## retrieval-context, repetition 1

Passed


| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 4409.446 | 1677.644 |
| Input tokens | 114 | 114 |
| Output tokens | 18 | 18 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 1.000 | 1.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 61.95% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | passed | supplied quality fixtures passed |
| quality_score | passed | 1.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | passed | All guided execution, quality and measured-objective checks passed |

## workflow-pads, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1906.579 | 1303.063 |
| Input tokens | 118 | 118 |
| Output tokens | 13 | 13 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 31.65% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

## workflow-pads, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- latency_regression: 2.71% regression &lt;= 0.00% allowed
- latency_improvement: -2.71% improvement &gt;= 0.00% required
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1270.835 | 1305.212 |
| Input tokens | 118 | 118 |
| Output tokens | 13 | 13 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 2.71% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -2.71% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed latency_regression: 2.71% regression &lt;= 0.00% allowed latency_improvement: -2.71% improvement &gt;= 0.00% required quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required The selected objective has no measured improvement |

## workflow-books, repetition 0

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- latency_regression: 39.79% regression &lt;= 0.00% allowed
- latency_improvement: -39.79% improvement &gt;= 0.00% required
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required
- The selected objective has no measured improvement

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1270.974 | 1776.732 |
| Input tokens | 118 | 118 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | failed | 39.79% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | failed | -39.79% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed latency_regression: 39.79% regression &lt;= 0.00% allowed latency_improvement: -39.79% improvement &gt;= 0.00% required quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required The selected objective has no measured improvement |

## workflow-books, repetition 1

Rejected

- Baseline and candidate must both pass the declared quality checks
- Baseline answer failed the declared json_subset criterion: mismatched keys: answer
- Candidate answer failed the declared json_subset criterion: mismatched keys: answer
- Native replay gates failed
- quality_fixtures: 1 supplied quality fixture case(s) failed
- quality_score: 0.0000 candidate quality &gt;= 1.0000 required

| Measurement | Baseline | Candidate |
| --- | --- | --- |
| Runtime (ms) | 1098.439 | 1072.211 |
| Input tokens | 118 | 118 |
| Output tokens | 14 | 14 |
| Model calls | 1 | 1 |
| Tool operations | 3 | 1 |
| Estimated model cost (USD) | unavailable | unavailable |
| Quality score | 0.000 | 0.000 |

| Gate | Result | Detail |
| --- | --- | --- |
| latency_regression | passed | 0.00% regression &lt;= 0.00% allowed |
| cost_regression | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| latency_improvement | passed | 2.39% improvement &gt;= 0.00% required |
| cost_improvement | indeterminate | cost could not be evaluated: a model call has no known pricing (see cost_breakdown.unknown_models). not gating. |
| retry_non_increase | passed | 0 candidate retries &lt;= 0 baseline retries |
| quality_fixtures | failed | 1 supplied quality fixture case(s) failed |
| quality_score | failed | 0.0000 candidate quality &gt;= 1.0000 required |
| guided_evidence | failed | Baseline and candidate must both pass the declared quality checks Baseline answer failed the declared json_subset criterion: mismatched keys: answer Candidate answer failed the declared json_subset criterion: mismatched keys: answer Native replay gates failed quality_fixtures: 1 supplied quality fixture case(s) failed quality_score: 0.0000 candidate quality &gt;= 1.0000 required |

Measurements describe this task set and run order. Repeated runs and independent tasks are needed to assess variability.

Native trace snapshots, frozen findings, replay results, linked interventions and paired study data accompany this report.
