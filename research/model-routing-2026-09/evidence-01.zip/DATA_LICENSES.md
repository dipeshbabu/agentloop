# Source attribution

GSM8K: OpenAI, grade-school-math, revision 3101c7d5072418e28b9008a6636bde82a006892c. https://github.com/openai/grade-school-math . Copyright (c) 2021 OpenAI; MIT License, reproduced in GSM8K-LICENSE.txt. Original test.jsonl bytes and their source hash are retained. Selected question indices, independent answers, source exclusions and selection algorithm are in the frozen plan.

AgentLoop and study code are Apache-2.0; see LICENSE. Dataset rights remain separate. Model weights, inference binaries and dependency implementations are not distributed.
