# Study: Capability-checked routing: held-out tasks

Descriptive paired comparisons. Bootstrap intervals assume exchangeable independent pairs; repeated tasks may require cluster-aware analysis. No significance decision is made.

Deltas are candidate minus baseline. Negative latency/cost deltas indicate reductions.

Cost statistics use evaluable runs or pairs only; counts disclose missing observations.

## Condition: baseline

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0.5 | 0.5 | 0 | 1 | not requested |
| quality_score | 12 | 0 | 0.5 | 0.5 | 0 | 1 | not requested |
| runtime_ms | 12 | 0 | 994.356 | 706.424 | 598.351 | 2470.51 | not requested |
| input_tokens | 12 | 0 | 89.1667 | 86.5 | 76 | 116 | not requested |
| output_tokens | 12 | 0 | 18.8333 | 10.5 | 7 | 64 | not requested |
| model_call_count | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| tool_call_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 6}`
Success basis: `{"task_metadata_and_execution": 12}`

## Condition: candidate

Runs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| quality_score | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| runtime_ms | 12 | 0 | 318.406 | 314.111 | 302.92 | 340.157 | not requested |
| input_tokens | 12 | 0 | 89.1667 | 86.5 | 76 | 116 | not requested |
| output_tokens | 12 | 0 | 10.8333 | 11 | 10 | 12 | not requested |
| model_call_count | 12 | 0 | 1 | 1 | 1 | 1 | not requested |
| tool_call_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

Failure categories: `{"task_failure": 12}`
Success basis: `{"task_metadata_and_execution": 12}`

## Paired comparison: candidate

Matched pairs: 12

| Metric | Count | Missing | Mean | Median | P05 | P95 | Bootstrap interval |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| success | 12 | 0 | -0.5 | -0.5 | -1 | 0 | not requested |
| quality_score | 12 | 0 | -0.5 | -0.5 | -1 | 0 | not requested |
| runtime_ms | 12 | 0 | -675.951 | -392.557 | -2167.59 | -282.898 | not requested |
| input_tokens | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| output_tokens | 12 | 0 | -8 | 1 | -54 | 3 | not requested |
| model_call_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| tool_call_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| retry_count | 12 | 0 | 0 | 0 | 0 | 0 | not requested |
| cost_usd | 0 | 12 | unavailable | unavailable | unavailable | unavailable | not requested |

### Unmatched runs

| Side | Run | Reason |
| --- | --- | --- |
| — | — | None |
