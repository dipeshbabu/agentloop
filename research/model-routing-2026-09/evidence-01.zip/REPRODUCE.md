# Reproduce capability-checked model routing

All32 planned trials are retained:8pilot+24held-out. Baseline held-out quality6/12, routed candidate0/12; six losses. Fourteen trials failed output handling. Tokenizer counts matched provider prompt usage32/32. The faster candidate did not meet quality requirements. All operating costs are unknown, paid-provider spend0. No route was promoted.

Use a complete AgentLoop checkout at bb027c2824cdd5a43ffbb95ecfac5d09df2e61b7 with every included source/ file overlaid, preserving bytes. The snapshots include the new routing modules, compatible shared harness error-usage support, study runner and scorer. These files are an overlay, not a separately installable distribution. The plan verifies frozen code, model and task hashes.

Recompute without inference:

    python -m examples.routing_study.export --plan PATH_TO_UNPACKED/study/plan.json --out NEW_REPORT_DIRECTORY

The exporter regrades original model text, validates routing/harness/usage and native traces, checks prediction registration before candidates, reconstructs immutable interventions, and uses native paired studies plus shared task-weighted statistics. Missing slots remain in planned denominators. The original report is in study/report/.

For new execution, create a fresh protocol with examples.routing_study.protocol and independently fixed task/scorer/model settings; never rewrite this plan after observing outcomes. Current preparation excludes prior#181 and#189 task indices. Run the baseline before candidate for each repetition so original predictions are archived first; fixed ordering remains a confound. Each condition uses a fresh request, client, usage collector and HarnessRun. Both original and substituted models receive the same controlled routing path and exact pre-dispatch tokenizer checks. No fallback is configured in the measured study; transport/stream fallback paths have offline SDK-shaped tests.

The plan pins both GGUF model repositories/revisions/hashes and the provider is official llama.cpp b10964 Windows Vulkan. Runtime ZIP SHA-256:1ee3ad952f4ba71f438bd6d7bebef19e1c7af04adcaa35d08b4ddabb27d4c642.

    llama-server --model MODEL_FILE --host 127.0.0.1 --port 8766 --ctx-size 4096 --n-gpu-layers 99 --threads 6 --batch-size 256 --ubatch-size 128 --parallel 1 --metrics --cors-origins localhost --no-cors-credentials --no-webui --no-cache-prompt

Wait for /health, retain a fixed readiness warmup outside measurement, then run examples.routing_study.runner --plan NEW_ROOT/plan.json --condition baseline-or-candidate --repetition 0-or-1 --model-file MODEL_FILE --execute. /apply-template and /tokenize perform preprocessing rather than inference; their time is included in measured decisions. Repeated seeds do not prove determinism. Model loading is excluded. Both setup probes and all four readiness requests are retained.

An initial startup wrapper stalled before any task or warmup. Correcting its PowerShell launch did not change frozen code/configuration or discard an outcome. Server console logs, model weights and inference binaries are excluded. No task/output artifacts are redacted. Public benchmark tasks may overlap model training, and this small single-host study does not establish a general model ranking or production safety.
