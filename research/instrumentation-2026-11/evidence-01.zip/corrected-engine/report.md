# Finding benchmark

Corpus-specific diagnostics, not universal precision or production savings. Abstention means no emitted finding, not a proven negative. Unknown and ambiguous labels are not correctness trials. Timings include saved evidence validation, not judge inference.

Corpus: `0dd18272b0c34a794f6e1c149f097ca313c5e0b53bb7ca9f6d13e416c0da79da`

| Rule | Version | Cases | TP | FP | Unknown/ambiguous | Abstentions | Precision | FPR |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| add_schema_validation | 1.2 | 2 | 1 | 0 | 0 | 1 | 1.0 | 0.0 |
| batch_model_calls | 1.2 | 2 | 1 | 0 | 0 | 1 | 1.0 | 0.0 |
| context_relevance | 1.0 | 4 | 1 | 0 | 2 | 3 | 1.0 | 0.0 |
| low_contribution | 1.0 | 4 | 1 | 0 | 2 | 3 | 1.0 | 0.0 |
| parallelize_tools | 1.1 | 4 | 1 | 0 | 1 | 2 | 1.0 | 0.0 |
| retry_usefulness | 1.0 | 4 | 1 | 0 | 2 | 3 | 1.0 | 0.0 |
| semantic_no_progress | 1.0 | 4 | 1 | 0 | 2 | 3 | 1.0 | 0.0 |
| semantic_redundancy | 1.0 | 4 | 1 | 0 | 2 | 3 | 1.0 | 0.0 |

Confidence labels are ordinal within each rule; they are not calibrated probabilities. JSON retains coverage, evidence completeness, backend/config identities, per-case findings and measured analysis overhead.

Release gate: PASS; regressions: 0; incomplete: 0; explicit review: none.
